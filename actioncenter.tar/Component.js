sap.ui.define(['sap/ui/core/UIComponent', 'sap/ui/model/json/JSONModel'],
	function(UIComponent, JSONModel) {
	"use strict";

	var Component = UIComponent.extend("cis.actioncenter.Component", {

		onCardReady: async function (oCard) {
			// resolving the destination
			this.oCard = oCard;
			var aPromises = [];
			var oJsonModel = new JSONModel();
			this.setModel(oJsonModel, "Instances");
			var oTaskCollectionJsonModel = new JSONModel();
			this.setModel(oTaskCollectionJsonModel, "TaskInstances");
			var oAssessmentsModel = new JSONModel();
			this.setModel(oAssessmentsModel, "Assessments");
			await this._getUserDetails(oCard);
			oCard.resolveDestination("Emission_CAP").then(function () {
				var pCreateAssessmentCall = new Promise(function(resolve, reject) {
				oCard.request({
					"url": "{{destinations.Emission_CAP}}/CreateAssessment",
					"mode": "cors",
					"method": "GET",
					"withCredentials": true
				}).then(function (oData) {
					console.log(oData)
					this.getModel("Assessments").setProperty("/assessments", oData.value);
				}.bind(this)).catch(function (oError) {
					console.log(oError);
					reject();
				});
			}.bind(this));
			}.bind(this));
			
			oCard.resolveDestination("bpmWorkflowDestination").then(function (sUrl) {
				var pWfTaskCollectionCall = new Promise(function(resolve, reject) {
					oCard.request({
						"url": "{{destinations.bpmWorkflowDestination}}/rest/v1/task-instances?workflowDefinitionId=waterWorkflow,cis.wastemanagementwf,com.cis.sustainbility_workflow",
						"mode": "cors",
						"method": "GET",
						"withCredentials": true
					}).then(function (oData) {
						// If needed modify the data or chain another request.
						let aTasks = oData.slice(0);
						let aFilteredTaskData = this._filterResponseOnLoggedUserInfo(aTasks);
						let aAssessmentsModel = this.getModel("Assessme	nts");
						let aInstancesData = [...aAssessmentsModel.getProperty("/assessments"), ...aFilteredTaskData];
						aAssessmentsModel.setProperty("/assessments", aInstancesData);
						let aTaskInstanceDetails = this.getModel("Assessments").getProperty("/assessments");
						let iReadyCount = 0;
						let iCompletedCount = 0;
						let iCancelledCount = 0;
						let iReservedCount=0;
						let iRunningCount=0;
						aTaskInstanceDetails.forEach(function(oTaskInstanceDetail){
						  if(oTaskInstanceDetail.Status){
							if(oTaskInstanceDetail.Status.includes("Complete")){
								iCompletedCount++;
							}
						  }else if(oTaskInstanceDetail.status){
							if(oTaskInstanceDetail.status.includes("COMPLETED")){
							    iCompletedCount++;
							}
						  }
						  if(oTaskInstanceDetail.Status){ 
							if(oTaskInstanceDetail.Status.includes("Running")){
								iRunningCount++;
							}
						  }
						  if(oTaskInstanceDetail.Status){
							if(oTaskInstanceDetail.Status.includes("Canceled")){
								iCancelledCount++;
							}
						  }else if(oTaskInstanceDetail.status){
							if(oTaskInstanceDetail.status.includes("CANCELED")){
								iCancelledCount++;
							}
						  }
						 if(oTaskInstanceDetail.status){ 
						  	if(oTaskInstanceDetail.status.includes("RESERVED")){
								iReservedCount++;
							}
						 }
						 if(oTaskInstanceDetail.status){ 
							if(oTaskInstanceDetail.status.includes("READY")){
								iReadyCount++;
						  }
					   }
						})
						this.getModel("TaskInstances").setProperty("/Completed", iCompletedCount);
						this.getModel("TaskInstances").setProperty("/Cancelled", iCancelledCount);
						this.getModel("TaskInstances").setProperty("/Ready", iReadyCount);
						this.getModel("TaskInstances").setProperty("/Reserved", iReservedCount);
						let aFilterItems = [];
						let aCreatedByFilterItems = [];
						aTasks.forEach(function(oTask){
							if(oTask.subject){
								aFilterItems.push({"text": oTask.subject, "key": "subject"});
							}
							if(oTask.createdBy){
								aCreatedByFilterItems.push({"text":oTask.createdBy, "key":"createdBy"});
							}
						});
						let oJsonObject = aFilterItems.map(JSON.stringify);
						let oCreatedByJsonObject = aCreatedByFilterItems.map(JSON.stringify);
						let aUniqueSet = new Set(oJsonObject);
						let aCreatedByUniqueSet = new Set(oCreatedByJsonObject);
						let aUniqueArray = Array.from(aUniqueSet).map(JSON.parse);
						let aCreatedByUniqueArray = Array.from(aCreatedByUniqueSet).map(JSON.parse);
						this.getModel("TaskInstances").setProperty("/TaskInstancesFilterItems", aUniqueArray);
						this.getModel("TaskInstances").setProperty("/TaskInstancesCreatedByFilterItems", aCreatedByUniqueArray);
						resolve();
					}.bind(this)).catch(function (oError) {
						console.log(oError);
						reject();
					});
				}.bind(this));
			}.bind(this));

		},
		_getUserDetails: async function(oCard){
			await oCard.getHostInstance().getContextValue("sap.workzone/currentUser").then(function(oContext){
				this.getModel("TaskInstances").setProperty("/loggedUserInfo", oContext);
			}.bind(this)).catch(function (oError) {
				console.log(oError);
			});
		},
		_filterResponseOnLoggedUserInfo: function(aTasks){
			let oTaskInstanceModel = this.getModel("TaskInstances").getProperty("/loggedUserInfo");
			let aFilteredTasks = [];
			aTasks.forEach(function(oTask, iIndex, aTasks){
				let oTaskObj = oTask;
				oTask.recipientUsers.forEach(function(oRecipentUser, iIndex, oTasks){
					if(oRecipentUser.toLowerCase() === oTaskInstanceModel.email.value.toLowerCase()){
						aFilteredTasks.push(oTaskObj);
					}
				})
			})
			return aFilteredTasks;
		},
	});

	return Component;

});
