sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/integration/Host",
	"sap/ui/model/json/JSONModel",
	'sap/ui/core/Fragment',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
], function (Controller, Host, JSONModel, Fragment, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("cis.actioncenter.Card", {
		onInit: function () {
			let aTasks = this.getView().getModel("TaskInstances").getProperty("/TaskInstancesFilterItems");
			let aCreatedByTasks = this.getView().getModel("TaskInstances").getProperty("/TaskInstancesCreatedByFilterItems");
			let oFilters =
			{
				"Filters": [
					{
						"type": "Priority",
						"key": "priority",
						"values": [
							{
								"text": "MEDIUM",
								"key": "priority"
							}
						]
					},
					{
						"type": "Status",
						"key": "status",
						"values": [
							{
								"text": "COMPLETED",
								"key": "status"
							},
							{
								"text": "RESERVED",
								"key": "status"
							},
							{
								"text": "CANCELED",
								"key": "status"
							},
							{
								"text": "READY",
								"key": "status"
							},
							{
								"text": "Complete",
								"key": "status"
							},
							{
								"text": "Running",
								"key": "status"
							},
							{
								"text": "Canceled",
								"key": "status"
							}
						]
					},
					{
						"type":"Subject",
						"key":"subject",
						"values":aTasks
					},
					{
						"type":"CreatedBy",
						"key":"createdBy",
						"values":aCreatedByTasks
					}
				]
			}
			this.getView().getModel("TaskInstances").setProperty("/filters", oFilters);
		},
		onPressNumericContent: function () {
		},
		onListItemPress: function (oEvent) {
			const oBinindingContext = oEvent.getSource().getBindingContext("Assessments").getObject();
			let oCard = this.getOwnerComponent().oCard;
			if(oBinindingContext.Type === "01"){
				oCard.triggerAction({
					type: "Navigation",
					parameters: {
						"ibnTarget": {
							"semanticObject": "employee",
							"action": "submit"
						},
						"ibnParams": {
							"workFlowInstanceType": "/RouteEmissionWF",
							"AssessmentID": oBinindingContext.AssessmentID
						}
					}
				});
			}else if(oBinindingContext.Type === "02"){
				oCard.triggerAction({
					type: "Navigation",
					parameters: {
						"ibnTarget": {
							"semanticObject": "watermanagement",
							"action": "submit"
						},
						"ibnParams": {
							"AssessmentID": oBinindingContext.AssessmentID
						}
					}
				});
			}else if(oBinindingContext.Type === "03"){

				oCard.triggerAction({
					type: "Navigation",
					parameters: {
						"ibnTarget": {
							"semanticObject": "wastemanagement",
							"action": "submit"
						},
						"ibnParams": {
							"AssessmentID": oBinindingContext.AssessmentID
						}
					}
				});
			}

		},

		onPressShowAll: function () {
			let oCard = this.getOwnerComponent().oCard;
			oCard.triggerAction({
				type: "Navigation",
				parameters: {
					"ibnTarget": {
						"semanticObject": "employee",
						"action": "submit"
					},
					// "ibnParams": {
					// 	"RouteSurvey": "/RouteSurvey"
					// }
				}
			});
		},

		handleFilterButtonPress: function (oEvent) {
			if (!this.oDefaultDialog) {
				this.oDefaultDialog = Fragment.load({
					id: this.getView().getId(),
					name: "cis.actioncenter.actionFilters",
					controller: this
				}).then(function (oDialog) {
					oDialog.setModel(this.getView().getModel("TaskInstances"));
					this.getView().addDependent(oDialog);
					return oDialog;
				}.bind(this));
			}
			this.oDefaultDialog.then(function (oDialog) {
				oDialog.openFilterDialog();
				document.getElementById("__dialog0").style.height = "350px";
			}.bind(this));
		},
		handleFilterClearButtonPress: function () {
			let oFacetFilter = this.byId("idFacetFilter");
			let aFacetFilterLists = oFacetFilter.getLists();

			for (var i = 0; i < aFacetFilterLists.length; i++) {
				aFacetFilterLists[i].setSelectedKeys();
			}

			this._applyFilter([]);
		},
		formatTitle: function (sActiveSteps, sCompletedSteps) {
			let sTitle = "";
			sTitle = sActiveSteps ? sActiveSteps : sCompletedSteps;
			return sTitle;
		},
		onFormatStatus: function (sStatusText,sStatusText2) {
			let sStatus = "None";
			if (sStatusText2) {
				if (sStatusText2.includes("READY")|| sStatusText2.includes("RUNNING")) {
					sStatus = "None";
				} else if (sStatusText2.includes("COMPLETED")) {
					sStatus = "Success";
				} else if (sStatusText2.includes("CANCELED")|| sStatusText2.includes("CANCELED")) {
					sStatus = "Error";
				}
			}else if(sStatusText){
				if (sStatusText.includes("Complete")) {
					sStatus = "Success";
				}else if(sStatusText.includes("Reject")){
					sStatus = "Error";
				}else if(sStatusText.includes("Running")){
					sStatus = "None";
				}
			}
			return sStatus;
		},
		formatCreatedBy: function (sUsers, sCreatedBy) {
			if (sCreatedBy) {
				return "Created By: " + sCreatedBy;
			}else{
				return "Created By: " + sUsers;
			}
		},
		onFormatStatusText: function (sStatusText) {
			if (sStatusText) {
				return "Status: " + sStatusText;
			}
		},
		formatStatusDisplay: function(sStatus1, sStatus2){
			if (sStatus1) {
				return "Status: " + sStatus1;
			}else if(sStatus2){
				return "Status: " + sStatus2;
			}
		},
		formatPriority: function (sProrityText) {
			if (sProrityText) {
				return "Priority: " + sProrityText;
			}
		},
		onFormatCreatedAtDate: function (dDate) {
			return "Created On: " + new Date(dDate).toDateString();
		},
		onFormatCompletedAtDate: function (dDate) {
			return "Completed On: " + new Date(dDate).toDateString();
		},
		handleConfirm: function (oEvent) {
			var oFacetFilter = oEvent.getSource();
			this._filterModel(oFacetFilter);
		},
		_filterModel: function (oFacetFilter) {
			var mFacetFilterLists = oFacetFilter.getLists().filter(function (oList) {
				return oList.getSelectedItems().length;
			});

			if (mFacetFilterLists.length) {
				var oFilter = new Filter(mFacetFilterLists.map(function (oList) {
					return new Filter(oList.getSelectedItems().map(function (oItem) {
						if(oItem.getText() === "Complete"){
							oList.mProperties.key= "Status";
						}else if(oItem.getText() === "COMPLETED"){
							oList.mProperties.key= "status";
						}
						if(oList.getKey() === "")
						return new Filter(oList.getKey(), "EQ", oItem.getText());
					}), false);
				}), true);
				this._applyFilter(oFilter);
			} else {
				this._applyFilter([]);
			}
		},
		_applyFilter: function (oFilter) {
			// Get the Table (last thing in the VBox) and apply the filter
			var aListItems = this.byId("list");
			aListItems.getBinding("items").filter(oFilter);
		},
		formatAssessmentType: function(sValue, sWFDefinitionId){
			let sAssessmentType = "";
			if(sValue || sWFDefinitionId){
				if(sValue === "01" || sWFDefinitionId === "com.cis.sustainbility_workflow"){
					sAssessmentType = "Emission Management";
				}else if(sValue === "02" || sWFDefinitionId === "waterWorkflow"){
					sAssessmentType = "Water Management";
				}else{
					sAssessmentType = "Waste Management";
				}
				
			}
			return sAssessmentType;
			
		},
		handleSynchronize: async function(oEvent){
			let oCard = this.getOwnerComponent().getComponentData().__sapUiIntegration_card;
			var oJsonModel = new JSONModel();
			this.getView().setModel(oJsonModel, "Assessments");
			oCard.request({
				"url": "{{destinations.Emission_CAP}}/CreateAssessment",
				"mode": "cors",
				"method": "GET",
				"withCredentials": true
			}).then(async function (oData) {
				// If needed modify the data or chain another request.
				this.getView().getModel("Assessments").setProperty("/assessments", oData.value);
				await this._getTaskInstances();
			}.bind(this)).catch(function (oError) {
				console.log(oError);
			});
		},
		_getTaskInstances: async function(){
			let oCard = this.getOwnerComponent().getComponentData().__sapUiIntegration_card;
			await this._getUserDetails(oCard);
			oCard.resolveDestination("bpmWorkflowDestination").then(function (sUrl) {
			var pWfTaskCollectionCall = new Promise(function(resolve, reject) {
				oCard.request({
					"url": "{{destinations.bpmWorkflowDestination}}/rest/v1/task-instances?workflowDefinitionId=waterWorkflow,cis.wastemanagementwf,com.cis.sustainbility_workflow",
					"mode": "cors",
					"method": "GET",
					"withCredentials": true
				}).then(function (oData) {
					// If needed modify the data or chain another request.
					let aTasks = oData.slice(0);
					let aFilteredTaskData = this._filterResponseOnLoggedUserInfo(aTasks);
					let aAssessmentsModel = this.getView().getModel("Assessments");
					let aInstancesData = [...aAssessmentsModel.getProperty("/assessments"), ...aFilteredTaskData];
					aAssessmentsModel.setProperty("/assessments", aInstancesData);
					let aTaskInstanceDetails = this.getView().getModel("Assessments").getProperty("/assessments");
					let iReadyCount = 0;
					let iCompletedCount = 0;
					let iCancelledCount = 0;
					let iReservedCount=0;
					let iRunningCount=0;
					aTaskInstanceDetails.forEach(function(oTaskInstanceDetail){
					  if(oTaskInstanceDetail.Status){
						if(oTaskInstanceDetail.Status.includes("Complete")){
							iCompletedCount++;
						}
					  }else if(oTaskInstanceDetail.status){
						if(oTaskInstanceDetail.status.includes("COMPLETED")){
							iCompletedCount++;
						}
					  }
					  if(oTaskInstanceDetail.Status){ 
						if(oTaskInstanceDetail.Status.includes("Running")){
							iRunningCount++;
						}
					  }
					  if(oTaskInstanceDetail.Status){
						if(oTaskInstanceDetail.Status.includes("Canceled")){
							iCancelledCount++;
						}
					  }else if(oTaskInstanceDetail.status){
						if(oTaskInstanceDetail.status.includes("CANCELED")){
							iCancelledCount++;
						}
					  }
					 if(oTaskInstanceDetail.status){ 
						  if(oTaskInstanceDetail.status.includes("RESERVED")){
							iReservedCount++;
						}
					 }
					 if(oTaskInstanceDetail.status){ 
						if(oTaskInstanceDetail.status.includes("READY")){
							iReadyCount++;
					  }
				   }
					})
					this.getView().getModel("TaskInstances").setProperty("/Completed", iCompletedCount);
					this.getView().getModel("TaskInstances").setProperty("/Cancelled", iCancelledCount);
					this.getView().getModel("TaskInstances").setProperty("/Ready", iReadyCount);
					this.getView().getModel("TaskInstances").setProperty("/Reserved", iReservedCount);
					let aFilterItems = [];
					let aCreatedByFilterItems = [];
					aTasks.forEach(function(oTask){
						if(oTask.subject){
							aFilterItems.push({"text": oTask.subject, "key": "subject"});
						}
						if(oTask.createdBy){
							aCreatedByFilterItems.push({"text":oTask.createdBy, "key":"createdBy"});
						}
					});
					let oJsonObject = aFilterItems.map(JSON.stringify);
					let oCreatedByJsonObject = aCreatedByFilterItems.map(JSON.stringify);
					let aUniqueSet = new Set(oJsonObject);
					let aCreatedByUniqueSet = new Set(oCreatedByJsonObject);
					let aUniqueArray = Array.from(aUniqueSet).map(JSON.parse);
					let aCreatedByUniqueArray = Array.from(aCreatedByUniqueSet).map(JSON.parse);
					this.getView().getModel("TaskInstances").setProperty("/TaskInstancesFilterItems", aUniqueArray);
					this.getView().getModel("TaskInstances").setProperty("/TaskInstancesCreatedByFilterItems", aCreatedByUniqueArray);
					resolve();
				}.bind(this)).catch(function (oError) {
					console.log(oError);
					reject();
				});
			}.bind(this));
		}.bind(this));
	},
	_getUserDetails: async function(oCard){
		await oCard.getHostInstance().getContextValue("sap.workzone/currentUser").then(function(oContext){
			this.getView().getModel("TaskInstances").setProperty("/loggedUserInfo", oContext);
		}.bind(this)).catch(function (oError) {
			console.log(oError);
		});
	},
	_filterResponseOnLoggedUserInfo: function(aTasks){
		let oTaskInstanceModel = this.getView().getModel("TaskInstances").getProperty("/loggedUserInfo");
		let aFilteredTasks = [];
		aTasks.forEach(function(oTask, iIndex, aTasks){
			let oTaskObj = oTask;
			oTask.recipientUsers.forEach(function(oRecipentUser, iIndex, oTasks){
				if(oRecipentUser.toLowerCase() === oTaskInstanceModel.email.value.toLowerCase()){
					aFilteredTasks.push(oTaskObj);
				}
			})
		})
		return aFilteredTasks;
	},
	});
});